
# Task 2: Data Visualization and Storytelling 📊

## 🎯 Objective
Create visualizations that convey a compelling story using sales data.

## 🛠 Tools Used
- Power BI
- Dataset: Superstore.csv

## 📌 What I Did
- Cleaned the Superstore dataset
- Built a multi-page Power BI dashboard
- Visualized regional sales, profit trends, product analysis, and customer segments
- Highlighted key insights using DAX measures and storytelling techniques

## 📈 Key Visualizations
1. Sales & Profit by Region
2. Top 10 Products by Sales
3. Category-wise Profit Analysis
4. Monthly Sales Trend
5. Segment-wise Customer Distribution

## 💡 Business Insights
- West region leads in profit.
- Technology has highest sales.
- Sub-category 'Tables' shows losses despite volume.
- Corporate segment yields high average order value.

## ✅ Task Complete
- Dashboard PDF and PBIX file included.
- GitHub-ready folder with data and documentation.

## 🔗 Submission Link
Submit your repo link at: https://forms.gle/8Gm83s53KbyXs3Ne9
